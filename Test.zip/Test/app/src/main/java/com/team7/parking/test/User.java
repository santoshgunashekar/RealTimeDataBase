package com.team7.parking.test;

class User {
    private String name;
    private String email_address;
    private String contact_number;
    private String location;
    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail_address() {
        return email_address;
    }

    public void setEmail_address(String email_address) {
        this.email_address = email_address;
    }

    public User(String name, String email_address) {
        this.name = name;
        this.email_address = email_address;
    }
}
