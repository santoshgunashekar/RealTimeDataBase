package com.team7.parking.test;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.List;
import java.util.Locale;

public class Main2Activity extends AppCompatActivity implements LocationListener {
    //https://androstock.com/tutorials/getting-current-location-latitude-longitude-country-android-android-studio.html
    EditText name, email_address, phone, description;
    LocationManager locationManager;
    Button submit, get_loc;
    TextView display, display_loc;
    String total="";
    private final int CAMERA_REQUEST = 1888;
    ImageView imageView;
    String temp1, temp2, temp3, temp4;
    double latitude ;
    double longitude;
    DatabaseReference database = FirebaseDatabase.getInstance().getReference("People");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        name = (EditText) findViewById(R.id.et1);
        email_address = (EditText) findViewById(R.id.et2);
        phone = (EditText) findViewById(R.id.et3);
        description = (EditText) findViewById(R.id.et4);
        imageView= (ImageView) findViewById(R.id.iv1);
        submit = (Button) findViewById(R.id.btn1);


        final String value = getIntent().getExtras().getString("Money");

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //total = "";
                //total+="Name : "+name.getText().toString()+"\nEmail address : "+email_address.getText().toString();
                //total+="\nPhone Number : "+phone.getText().toString()+"\nDescription : "+description.getText().toString();
                //display.setText(total);
                getLocation();
                Intent intent = new Intent(Main2Activity.this, payment.class);
                intent.putExtra("Money",value);
                startActivity(intent);
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
                finish();
            }
        });

        if (ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION}, 101);

        }
    }
    void getLocation() {
        try {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000, 5, this);
        }
        catch(SecurityException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onLocationChanged(Location location) {
        double latitude = location.getLatitude();
        double longitude = location.getLongitude();
        //display_loc.setText("Latitude: " + location.getLatitude() + "\n Longitude: " + location.getLongitude());

        try {

            //Geocoder geocoder = new Geocoder(this, Locale.getDefault());
            //List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
            //display_loc.setText(display_loc.getText() + "\n"+addresses.get(0).getAddressLine(0)+", "+
                    //addresses.get(0).getAddressLine(1)+", "+addresses.get(0).getAddressLine(2));
            //String temp = display_loc.getText().toString();
            //temp = temp.replaceAll(", null","");
            //display_loc.setText(temp);
            //while(temp!="Before getting location"){
            temp1=name.getText().toString();
            temp2=email_address.getText().toString();
            temp3=phone.getText().toString();
            temp4=description.getText().toString();


            //}
        }catch(Exception e)
        {

        }

    }

    @Override
    public void onProviderDisabled(String provider) {
        Toast.makeText(Main2Activity.this, "Please Enable GPS and Internet", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CAMERA_REQUEST) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            StorageReference mStorageRef;
            mStorageRef = FirebaseStorage.getInstance().getReference();
            User user = new User(temp1, temp2, temp3, temp4, latitude, longitude);
            DatabaseReference myRef = database.child(temp1);
            myRef.setValue(user);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            photo.compress(Bitmap.CompressFormat.JPEG, 100, baos);
            byte[] data1 = baos.toByteArray();

            UploadTask uploadTask = mStorageRef.putBytes(data1);
            uploadTask.addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception exception) {
                    // Handle unsuccessful uploads
                }
            }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    // taskSnapshot.getMetadata() contains file metadata such as size, content-type, and download URL.
                    Uri downloadUrl = taskSnapshot.getDownloadUrl();
                }
            });
        }
    }


}
