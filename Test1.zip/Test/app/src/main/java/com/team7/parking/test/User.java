package com.team7.parking.test;

class User {
    private String name;
    private String email_address;
    private String contact_number;
    private String location;
    private String description;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getContact_number() {
        return contact_number;
    }

    public void setContact_number(String contact_number) {
        this.contact_number = contact_number;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail_address() {
        return email_address;
    }

    public void setEmail_address(String email_address) {
        this.email_address = email_address;
    }

    public User(String name, String email_address, String contact_number, String location, String description) {
        this.name = name;
        this.email_address = email_address;
        this.contact_number = contact_number;
        this.location = location;
        this.description = description;
    }
}
